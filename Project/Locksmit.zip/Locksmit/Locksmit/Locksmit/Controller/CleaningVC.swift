//
//  CleaningVC.swift
//  Locksmit
//
//  Created by MAC on 27/06/23.
//

import Foundation
import UIKit

// MARK: - Class Of UiViewController -

class CleaningVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var tblClean: UITableView!
    
    var lblClean = ["Bathroom Deep Cleaning", "Sofa Cleaning", "Kitchen Deep Cleaning", "Carpet Cleaning", "Full Home Deep Cleaning", "Offices and Shops Disinfection", "Home & Car Disinfection", "Car Cleaning"]
    
    var imgClean = ["1", "2", "3", "4", "5", "6", "7", "8"]
    
// MARK: - Button Action Method -
    
    @IBAction func btnBackTapped(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
        
    }
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         let nib = UINib(nibName: "CleaningViewCell", bundle: nil)
         self.tblClean.register(nib, forCellReuseIdentifier: "CleaningViewCell")
        
        self.tblClean.delegate = self
        self.tblClean.dataSource = self
        
    }
    
}

// MARK: - UITableViewDelegate & UITableViewDataSource method -

extension CleaningVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lblClean.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CleaningViewCell", for: indexPath) as! CleaningViewCell
        cell.lblClean.text = lblClean[indexPath.row]
        cell.imgClean.image = UIImage(named: imgClean[indexPath.row])
        return cell
    }
    
}
