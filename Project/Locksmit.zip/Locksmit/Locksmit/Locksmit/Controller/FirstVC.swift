//
//  FirstVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit

// MARK: - Class Of UiViewController -

class FirstVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var btnSafe: UIButton!
    
    var tm=Timer()
    var n=1
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.async {
            self.btnSafe.layer.cornerRadius = self.btnSafe.frame.size.height / 2
        }
        
        tm=Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(FirstVC.gotohome), userInfo: nil, repeats: true)
        
    }
    
// MARK: - Custom Function Of Gotohome -
    
    @objc func gotohome()
    {
        n+=1
        
        if n==3
        {
           dismiss(animated: true, completion: nil)
            let homeVC=storyboard?.instantiateViewController(identifier: "HomeVC") as! HomeVC
            self.navigationController?.pushViewController(homeVC, animated: true)
        }
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
