//
//  LSHomeVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit
import FirebaseAuth

// MARK: - Class Of UiViewController -

class LSHomeVC: UIViewController, KASlideShowDelegate, UISearchBarDelegate{
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var imgSlider: KASlideShow!
    @IBOutlet weak var colService: UICollectionView!
    @IBOutlet weak var searchService: UISearchBar!
    
    
    var imageService = ["Saloon", "Cleaning", "Hair", "Repair", "Massage", "Electronics", "Plumbbers", "Painters", "Carpenters", "AC", "Controls", "Yoga"]
    
    var lblService = ["Salon at Home", "Cleaning & Disinfection", "Haircut at Home", "Appliance Reapair", "Massage Therapy", "Electroinics", "Plumbers", "Painters", "Carpenters", "AC Services & Repair", "Pest Controls", "Yoga & Fitness"]
    
    var serviceSearch = [String]()
    
    var searching = false
    
// MARK: - View Did Load Method -
    
        override func viewDidLoad() {
            super.viewDidLoad()
            
            searchService.delegate = self
            
            imageSlider()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
            
            self.colService.delegate = self
            self.colService.dataSource = self
        
    }
    
    // MARK: - Searchbar delegate & datasource method -
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        serviceSearch = lblService.filter({$0.prefix(searchText.count) == searchText})
        searching = true
        self.colService.reloadData()
        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searching = false
        searchBar.text = ""
        colService.reloadData()
    }
    
// MARK: - Custom Function Of imageslider -
   
    func imageSlider()
    {
        imgSlider.delegate = self
        imgSlider.delay = 2 // Delay between transitions
        imgSlider.transitionDuration = 0.5 // Transition duration
        imgSlider.transitionType = KASlideShowTransitionType.slide // Choose a transition type (fade or slide)
        imgSlider.imagesContentMode = .scaleToFill // Choose a content mode for images to display
        imgSlider.addImages(fromResources: ["AD1","AD2","AD3","AD4","AD5"]) // Add images from resources
        //slideShow.add(KASlideShowGestureType.tap) // Gesture to go previous/next directly on the image (Tap or Swipe)
        imgSlider.start()
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}

// MARK: - UICollectionViewDelegate & UICollectionViewDataSource method -

extension LSHomeVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searching {
           return serviceSearch.count
        } else {
           return lblService.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ServicesCell", for: indexPath) as! ServicesCell
        if searching {
            cell.imgServices.image = UIImage(named: imageService[indexPath.row])
            cell.lblServices.text = serviceSearch[indexPath.row]
        } else {
            cell.imgServices.image = UIImage(named: imageService[indexPath.row])
            cell.lblServices.text = lblService[indexPath.row]
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout:
         UICollectionViewLayout, sizeForItemAt indexPath: IndexPath
    ) -> CGSize {
        
        return CGSize(width: (view.frame.size.width/3)-3,
                      height: (view.frame.size.width/3)-3)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            
            
            
        }
        
        else if indexPath.row == 1 {
            
            let vc = storyboard?.instantiateViewController(identifier: "CleaningVC") as! CleaningVC
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
            
        }
        
        else if indexPath.row == 2 {
            
            
            
        }
        
        else if indexPath.row == 3 {
            
            
            
        }
        
        else if indexPath.row == 4 {
            
            
            
        }
        
        else if indexPath.row == 5 {
            
            
            
        }
        
        else if indexPath.row == 6 {
            
            
            
        }
        
        else if indexPath.row == 7 {
            
            
            
        }
        
        else if indexPath.row == 8 {
            
            
            
        }
        
        else if indexPath.row == 9 {
            
            
            
        }
        
        else if indexPath.row == 10 {
            
            
            
        }
        
        else if indexPath.row == 11 {
            
            
            
        }
        
        else {
            print("Error")
        }
        
    }
    
    
}
