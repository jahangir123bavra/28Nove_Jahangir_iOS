//
//  LockSmitVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit
import WebKit
import Cosmos
import FirebaseDatabase
import FirebaseAuth

// MARK: - Class Of UiViewController -

class LockSmitVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var vwRating: CosmosView!
    @IBOutlet weak var vwFeedback: UITextView!
    @IBOutlet weak var btnFeedback: UIButton!
    
    /* var Facebook = "https://www.facebook.com/TOPSRajkot?mibextid=ZbWKwL"
    var Insta = "https://instagram.com/topstech?igshid=MzRlODBiNWFlZA=="
    var Youtube = "https://youtube.com/@topstechnologies6807" */
    
    var urlToPass: URL!
    
    var rootRef = Database.database().reference()
    
    var data=Dictionary<String,Any>()
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        rootRef=Database.database().reference()
        
        rootRef.observe(.value, with: { snapshot in
          // This is the snapshot of the data at the moment in the Firebase database
          // To get value from the snapshot, we user snapshot.value
          //print(snapshot.value as Any)
            self.data=snapshot.value as! [String : Any]
         //   let Email = self.data["email"] as? String
           // self.data["email"] = self.txtEmail.text! as! Any
          
            print(self.data)
        })
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        self.vwFeedback.layer.borderColor = UIColor.darkGray.cgColor
        self.vwFeedback.layer.borderWidth = 1.0
        
        DispatchQueue.main.async {
            
            self.vwFeedback.layer.cornerRadius = self.vwFeedback.frame.size.height / 10
            
            self.btnFeedback.layer.cornerRadius = self.btnFeedback.frame.size.height / 2
            
            
            
        }
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnFacebook(_ sender: Any)
    {
        
                urlToPass = URL(string: "https://www.facebook.com/TOPSRajkot?mibextid=ZbWKwL")
                performSegue(withIdentifier: "AboutVC", sender: nil)
    
    }
    

    
    @IBAction func btnInstaTapped(_ sender: Any) {
        
        urlToPass = URL(string: "https://instagram.com/topstech?igshid=MzRlODBiNWFlZA==")
        performSegue(withIdentifier: "AboutVC", sender: nil)
        
    }
    
    @IBAction func btnYoutubeTapped(_ sender: Any) {
        
        urlToPass = URL(string: "https://youtube.com/@topstechnologies6807")
        performSegue(withIdentifier: "AboutVC", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

            super.prepare(for: segue, sender: sender)

            guard let destination = segue.destination as? AboutVC else { return }

            destination.receivedUrl = urlToPass
            urlToPass = nil
        }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
            if let urlToPass = urlToPass {
                // check if your application can open the NSURL instance
                if !UIApplication.shared.canOpenURL(urlToPass) {
                    let alertController = UIAlertController(title: "Cannot open URL.", message: "This is an invalid URL.", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "Okay", style: .cancel, handler: nil)
                    alertController.addAction(ok)
                    present(alertController, animated: true, completion: nil)
                }
                return UIApplication.shared.canOpenURL(urlToPass)
            }
            return false
        }
    

    
    @IBAction func btnFeedbackTapped(_ sender: Any) {
        
        if self.vwFeedback.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "FeedBack", message: "Please Enter Feedback", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        else {
            
            let alert = UIAlertController(title: "FeedBack", message: "Registration Succesfully", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "OK", style: .default) { [self] UIAlertAction in
                
                let data=["rating":vwRating.rating,
                          "feedback":vwFeedback.text!] as [String : Any] 
                rootRef.child("FeedBack").childByAutoId().setValue(data)
                          
                
            }
            
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
