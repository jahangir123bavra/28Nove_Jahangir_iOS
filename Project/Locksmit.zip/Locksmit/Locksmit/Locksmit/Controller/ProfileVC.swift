//
//  ProfileVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit
import FirebaseDatabase
import FirebaseAuth

// MARK: - Class Of UiViewController -

class ProfileVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    @IBOutlet weak var vwName: UIView!
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var vwNumber: UIView!
    @IBOutlet weak var txtCode: UITextField!
    @IBOutlet weak var vwCountry: UIView!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var txtSelectCountry: UITextField!
    @IBOutlet weak var vwState: UIView!
    @IBOutlet weak var txtSelectState: UITextField!
    @IBOutlet weak var vwCity: UIView!
    @IBOutlet weak var txtSelectCity: UITextField!
    
    @IBOutlet weak var btnProfile: UIButton!
    @IBOutlet weak var btnLogout: UIButton!
    
    var rootRef = Database.database().reference()
    
    var data=Dictionary<String,Any>()
    
        var pickerCode = UIPickerView()
        var arrCode = ["+91", "+1", "+61", "+27", "+64"]
        
        var pickerCoutry = UIPickerView()
        var arrCountry = ["India", "America", "Australia", "South Africa", "New Zeland"]
        
        var pickerState = UIPickerView()
        var arrState = ["Gujarat", "Washington", "Tasmania", "Cape Town", "Auckland"]
        
        var pickerCity = UIPickerView()
        var arrCity = ["Ahmedabad", "Olympia", "Hobart", "Johannesburg", "Rotorua"]
    
// MARK: - Button Action Method -
    
    
    @IBAction func btnProfileTapped(_ sender: Any) {
        
        if self.txtFullName.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtCode.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtMobileNumber.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtSelectCountry.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtSelectState.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        if self.txtSelectCity.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "Login", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        else {
            
            let alert = UIAlertController(title: "Registration", message: "Registration Succesfully", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "OK", style: .default) { [self] UIAlertAction in
                
                let data=["name":txtFullName.text!,
                          "code":txtCode.text!,
                          "mobile":txtMobileNumber.text!,
                          "country":txtSelectCountry.text!,
                          "state":txtSelectState.text!,
                          "city":txtSelectCity.text!]
                rootRef.child("UpdateProfile").childByAutoId().setValue(data)
                
                
                
                
             /*   let mainTab = self.storyboard?.instantiateViewController(identifier: "TabBarController")
                mainTab!.modalPresentationStyle = .fullScreen
                self.present(mainTab!, animated: true, completion: nil) */
                
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            
        }
        
        
    }
    
// MARK: - Custom Function Of applystyle -
    
    func ApplyStyle() {
        
        self.vwName.layer.borderColor = UIColor.darkGray.cgColor
        self.vwName.layer.borderWidth = 1.0
        
        self.vwNumber.layer.borderColor = UIColor.darkGray.cgColor
        self.vwNumber.layer.borderWidth = 1.0
        
        self.vwCountry.layer.borderColor = UIColor.darkGray.cgColor
        self.vwCountry.layer.borderWidth = 1.0
        
        self.vwState.layer.borderColor = UIColor.darkGray.cgColor
        self.vwState.layer.borderWidth = 1.0
        
        self.vwCity.layer.borderColor = UIColor.darkGray.cgColor
        self.vwCity.layer.borderWidth = 1.0
        
        DispatchQueue.main.async {
            
            self.vwName.layer.cornerRadius = self.vwName.frame.size.height / 2
            
            self.vwNumber.layer.cornerRadius = self.vwNumber.frame.size.height / 2
            
            self.vwCountry.layer.cornerRadius = self.vwCountry.frame.size.height / 2
            
            self.vwState.layer.cornerRadius = self.vwState.frame.size.height / 2
            
            self.vwCity.layer.cornerRadius = self.vwCity.frame.size.height / 2
            
            self.btnProfile.layer.cornerRadius = self.btnProfile.frame.size.height / 2
            
            self.btnLogout.layer.cornerRadius = self.btnLogout.frame.size.height / 2
            
        }
        
    }
    
    // MARK: - Custom Function Of delegate -
    
    func Delgate() {
        
        self.pickerCode.delegate = self
        self.pickerCode.dataSource = self
        
        self.txtCode.inputView = pickerCode
        
        self.pickerCoutry.delegate = self
        self.pickerCoutry.dataSource = self
        
        self.txtSelectCountry.inputView = pickerCoutry
        
        self.pickerState.delegate = self
        self.pickerState.dataSource = self
        
        self.txtSelectState.inputView = pickerState
        
        self.pickerCity.delegate = self
        self.pickerCity.dataSource = self
        
        self.txtSelectCity.inputView = pickerCity
        
    }
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ApplyStyle()
        
        Delgate()
        
        rootRef=Database.database().reference()
        
        rootRef.observe(.value, with: { snapshot in
          // This is the snapshot of the data at the moment in the Firebase database
          // To get value from the snapshot, we user snapshot.value
          //print(snapshot.value as Any)
            self.data=snapshot.value as! [String : Any]
         //   let Email = self.data["email"] as? String
           // self.data["email"] = self.txtEmail.text! as! Any
          
            print(self.data)
        })
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnLogoutTapped(_ sender: Any) {
        
        if Auth.auth().currentUser != nil {
                do {
                    try Auth.auth().signOut()
                    let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")
                    vc.modalPresentationStyle = .fullScreen
                    present(vc, animated: true, completion: nil)
                    
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}

// MARK: - UIPickerViewDelegate & UIPickerViewDataSource method -

extension ProfileVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerCode{
            return self.arrCode.count
        }else if pickerView == pickerCoutry{
            return self.arrCountry.count
        }else if pickerView == pickerState{
            return self.arrState.count
        }else if pickerView == pickerCity{
            return self.arrCity.count
           }
        else {
            return 1
        }
     }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == pickerCode{
            return self.arrCode[row]
        }else if pickerView == pickerCoutry{
            return self.arrCountry[row]
        }else if pickerView == pickerState{
            return self.arrState[row]
        }else if pickerView == pickerCity{
            return self.arrCity[row]
        }
        else {
            return nil
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerCode{
            self.txtCode.text = self.arrCode[row]
        } else if pickerView == pickerCoutry{
            self.txtSelectCountry.text = self.arrCountry[row]
        }else if pickerView == pickerState{
            self.txtSelectState.text = self.arrState[row]
        }else if pickerView == pickerCity{
            self.txtSelectCity.text = self.arrCity[row]
        }
        else{
            return
        }
        
        self.view.endEditing(true)
        
    }
    
}

