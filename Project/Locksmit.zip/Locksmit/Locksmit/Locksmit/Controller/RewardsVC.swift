//
//  RewardsVC.swift
//  Locksmit
//
//  Created by MAC on 26/06/23.
//

import Foundation
import UIKit
import WebKit

// MARK: - Class Of UiViewController -

class RewardsVC: UIViewController {
    
// MARK: - Outlet Variable-
    
    var rewardsUrl = "https://www.rewardlink.io/redeem"
    
    @IBOutlet weak var webRewards: WKWebView!
    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        let url=URL(string: rewardsUrl)
        let urlReq=URLRequest(url: url!)
        webRewards.load(urlReq)
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}
