//
//  SignUpVC.swift
//  Locksmit
//
//  Created by MAC on 04/07/23.
//

import Foundation
import UIKit
import FirebaseAuth

// MARK: - Class Of UiViewController -

class SignUpVC: UIViewController {
    
// MARK: - Outlet Variable-
   
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnPassword: UIButton!
    
// MARK: - Button Action Method -
    
    @IBAction func btnHideShowPasswordTapped(_ sender: Any) {
        
        (sender as! UIButton).isSelected = !(sender as! UIButton).isSelected
        if(sender as! UIButton).isSelected {
            self.txtPassword.isSecureTextEntry = false
            btnPassword.setImage(UIImage(named: "OpenEyes"), for: .normal)
        }
        else {
            self.txtPassword.isSecureTextEntry = true
            btnPassword.setImage(UIImage(named: "HiddenEyes"), for: .normal)
        }
        
    }
    @IBAction func btnSignUpTapped(_ sender: Any) {
        
        
        if self.txtEmail.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "SignUp", message: "Please Enter Email", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
        
        
        
        
        if self.txtPassword.text!.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let alert = UIAlertController(title: "SignUp", message: "Please Enter Password", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "Ok", style: .default) { UIAlertAction in
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
        }
       
        else {
            
            Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
            
            let alert = UIAlertController(title: "SignUp", message: "SignUp Succesfully", preferredStyle: .alert)
            let actionOK = UIAlertAction(title: "OK", style: .default) { [self] UIAlertAction in
                
                
                
                let vc = storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                self.navigationController?.pushViewController(vc, animated: true)
                
             /*   let mainTab = self.storyboard?.instantiateViewController(identifier: "TabBarController")
                mainTab!.modalPresentationStyle = .fullScreen
                self.present(mainTab!, animated: true, completion: nil) */
                
            }
            alert.addAction(actionOK)
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }
    }
    

    
// MARK: - View Did Load Method -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     //   Delgate()
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        
    }
    
// MARK: - Button Action Method -
    
    @IBAction func btnBackTapped(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
// MARK: - viewWillAppear & viewWillDisappear method -
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
}


