//
//  ServicesCell.swift
//  Locksmit
//
//  Created by MAC on 27/06/23.
//

import UIKit

// MARK: - Class Of UiViewController -

class ServicesCell: UICollectionViewCell {
    
    @IBOutlet weak var imgServices: UIImageView!
    @IBOutlet weak var lblServices: UILabel!
}
